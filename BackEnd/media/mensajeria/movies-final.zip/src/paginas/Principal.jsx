import "../styles.css";

import { ProductosGrid } from "../ProductosGrid";
import { Search } from "../componentes/Search";
import { useQuery } from "../utils/utilidades";
import { useDebounce } from "../hooks/useDebounce";
export function Principal() {

  const query=useQuery().get("search");
  console.log("Query....:"+query);

  const debounceSearch=useDebounce(query,1000)

  return (
    <div className="App">
      <h1>Peliculas</h1>
      <h2>Listado de Peliculas</h2>
      <Search />
      <ProductosGrid key={debounceSearch} query={debounceSearch}/>
    </div>
  );
}
