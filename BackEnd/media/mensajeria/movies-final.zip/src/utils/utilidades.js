import { useLocation } from "react-router-dom";

export function useQuery(){
    //console.log('Location:'+useLocation().search);
    return new URLSearchParams(useLocation().search);
  }