// import productos from "./productos.json";
import styles from "./ProductosGrid.module.css";
import { ProductoCard } from "./ProductCard";
import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { useDebounce } from "./hooks/useDebounce";
import { useQuery } from "./utils/utilidades.js"
import InfiniteScroll from "react-infinite-scroll-component";
import { Spinner } from "./componentes/Spinner.jsx"

// esta función la sacamos fuera para rehusarla en otros componentes
// function useQuery(){
//   //console.log('Location:'+useLocation().search);
//   return new URLSearchParams(useLocation().search);
// }


export function ProductosGrid({query}) {
  const [movies, setMovies] = useState([]);
  const [pagina,setPagina]=useState(1);
  const [hasMore,setHasMore]=useState(true);
  
  // modificasmos y pasamos el query por parametro al componenete
  // const query=useQuery().get("search");
  // console.log("Query:"+query);
  //  const debounceSearch=useDebounce(query,1000)
 
  // `https://api.themoviedb.org/3/search/movie?query=${query}&api_key=57537ff19f381dd7b67eee1ea8b8164a`

  useEffect(() => {
    const url= query ?
     `https://api.themoviedb.org/3/search/movie?query=${query}&page=${pagina}&api_key=57537ff19f381dd7b67eee1ea8b8164a`
      :
      `https://api.themoviedb.org/3/discover/movie?page=${pagina}&api_key=57537ff19f381dd7b67eee1ea8b8164a`

    fetch(
      url
    )
      .then((res) => res.json())
      .then((json) => {
        console.log(json);
        
        // setMovies(json.results);
         setMovies((data)=>data.concat(json.results));
         setHasMore(json.page<json.total_pages)
      });
  }, [query,pagina]);

  return (
    <>
      <div className="lista">
        <InfiniteScroll
         dataLength={movies.length} //This is important field to render the next data
         next={()=>setPagina( (pant) => pant + 1 )}
         hasMore={hasMore}
         loader={<Spinner />}
         >
        <ul className={styles.contenedor}>
          {movies && movies.map((result) => (
              <ProductoCard key={result.id} movie={result} />
            ))}
        </ul>
        </InfiniteScroll>
      </div>
    </>
  );
}
