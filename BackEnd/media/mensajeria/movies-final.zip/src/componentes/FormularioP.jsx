import { useState } from "react";


//formulario controlado, ejemplo
export function FormularioP() {
  const [search, setSearch] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    setSearch(e.target.value.toUpperCase());
  };

  return (
    <form>
      <input type="text" 
            name="search"
            value={search} 
            onChange={handleSubmit}></input>
      <button type="submit">buscar</button>
      <p>Resultados para: {search} </p>
    </form>
  );
}
