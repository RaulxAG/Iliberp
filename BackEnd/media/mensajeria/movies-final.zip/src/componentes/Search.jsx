import { useEffect, useState } from "react";
import styles from "./Search.module.css";
import { useNavigate } from "react-router-dom";
import { FaSearch } from "react-icons/fa";
import { useQuery } from "../utils/utilidades";

export function Search({key}) {
  const history = useNavigate();
  const [search, setSearch] = useState("");

  // const handAlert = () => {
    
  //   let searchText = document.querySelector("#texto").value;
  //   history("/filtrar/?search=" + searchText);

  // };

  const query=useQuery();
  const sBusqueda=query.get("search");

// const sBusqueda=useQuery().get("search");
  
  useEffect( () => {
   setSearch(sBusqueda || '' )
  },[sBusqueda])

  const handleChange=(e) => {
    e.preventDefault();
    const value = e.target.value;
    setSearch(value)
    //console.log('search:' + value);
    history("/?search=" + value);
  }

  return (
    <div className={styles.formulario}>
      <input type="text" name="texto" id="texto" autoComplete="off"
        value={search}
        onChange={handleChange}/>
      <FaSearch />
      {/* <input type="submit" value="Buscar" 
        onClick={handAlert} /> */}
    </div>
  );
}
